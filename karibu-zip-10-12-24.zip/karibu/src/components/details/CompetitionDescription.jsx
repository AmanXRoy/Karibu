import React from 'react'

function CompetitionDescription() {
  return (
    <div>
        <h2 className='text-5xl font-semibold text-black text-center py-8 px-16'>
            Make it a reality by joining our Raffle tickets 
            <span className='text-primary'>today!</span>
        </h2>
        <div className="description">
            
        </div>
    </div>
  )
}

export default CompetitionDescription